function padDate(val){
    return val < 10 ? "0" + val : val;
}

export default padDate;
